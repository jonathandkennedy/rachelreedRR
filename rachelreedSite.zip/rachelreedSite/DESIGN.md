---
name: Coastal Prestige
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1c1c'
  surface-container: '#1f2020'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e4e2e1'
  on-surface-variant: '#c4c7c7'
  inverse-surface: '#e4e2e1'
  inverse-on-surface: '#303030'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c9c6c5'
  primary: '#c9c6c5'
  on-primary: '#313030'
  primary-container: '#0e0e0e'
  on-primary-container: '#7c7b7a'
  inverse-primary: '#5f5e5e'
  secondary: '#e5c280'
  on-secondary: '#402d00'
  secondary-container: '#5b430c'
  on-secondary-container: '#d2b070'
  tertiary: '#c8c6c2'
  on-tertiary: '#30312e'
  tertiary-container: '#0d0e0c'
  on-tertiary-container: '#7c7b77'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c9c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#ffdea3'
  secondary-fixed-dim: '#e5c280'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5b430c'
  tertiary-fixed: '#e4e2dd'
  tertiary-fixed-dim: '#c8c6c2'
  on-tertiary-fixed: '#1b1c19'
  on-tertiary-fixed-variant: '#474744'
  background: '#131313'
  on-background: '#e4e2e1'
  surface-variant: '#353535'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 84px
    fontWeight: '700'
    lineHeight: 92px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 60px
    fontWeight: '600'
    lineHeight: 72px
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 32px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.15em
spacing:
  container-max: 1440px
  gutter: 32px
  margin-desktop: 80px
  margin-mobile: 24px
  section-gap: 160px
---

## Brand & Style

This design system establishes a formidable and prestigious visual language for a high-stakes legal practice. It blends the aggressive, high-impact presence of top-tier criminal defense firms with the refined, editorial aesthetic of a luxury boutique. The intent is to evoke a sense of "relentless advocacy"—projecting both the clinical precision of a legal powerhouse and the sophisticated warmth of a coastal firm.

The design style is **Editorial Minimalism mixed with High-Contrast Boldness**. It utilizes expansive white space (or "black space" in dark mode) to create a sense of scale and authority. Large-scale typography serves as a structural element, while the ornate monogram acts as a seal of excellence, appearing as both a dominant branding mark and a subtle, textured watermark.

## Colors

The palette is rooted in power and heritage. 

- **Ink Black (#0E0E0E):** The foundation of the system, providing a deep, immersive background that communicates seriousness and absolute authority.
- **Champagne Gold (#B8985A):** Used strategically for accents, calls to action, and the "RR" monogram. It represents excellence and the premium nature of the practice.
- **Soft Cream (#F9F7F2):** Used for typography on dark backgrounds and as a primary surface color for high-contrast "Vogue" style sections. It provides a warmer, more sophisticated alternative to pure white.
- **Charcoal Neutral (#262626):** Employed for UI containers, borders, and secondary text to maintain depth without sacrificing legibility.

## Typography

The typography strategy relies on extreme contrast between the classic, high-stroke-contrast Serif and a sharp, contemporary Sans-Serif.

**Playfair Display** is used for all major headlines. In display settings, it should be set with tight tracking to maximize its "Vogue" editorial impact. **Hanken Grotesk** provides a clean, highly legible counterpoint for body copy and functional UI elements, ensuring the brand feels modern and accessible despite its prestigious roots. 

For technical legal data or "Results" metrics, use **Label-Caps** to create a structured, institutional feel.

## Layout & Spacing

The layout philosophy is **Large-Scale & Columnar**, favoring a 12-column grid with generous margins to enforce a "boutique" feel. 

Spacing is intentionally aggressive; large vertical gaps (160px+) between sections create a sense of pacing and importance, preventing the content from feeling "crowded"—a hallmark of luxury design. On mobile, the grid collapses to a single column, but the generous vertical rhythm is maintained to preserve the sense of prestige.

## Elevation & Depth

Depth in this system is achieved through **Tonal Layering and Low-Contrast Outlines** rather than traditional shadows. 

1. **Surface Tiering:** Use #0E0E0E for the base background and #1A1A1A for cards or contained sections. This creates a subtle "stacked" effect.
2. **Gold Outlines:** Use 1px Champagne Gold borders for primary interactive elements or to highlight "Results" modules.
3. **Monogram Watermarks:** The "RR" monogram should be used at 5-10% opacity in the background of large sections, acting as a textural element that suggests a physical, embossed quality.

## Shapes

To maintain a "formidable" and "aggressive" legal posture, the system utilizes **Sharp (0px)** corners for all primary containers, buttons, and input fields. Sharp angles communicate precision, discipline, and structural integrity. 

The only curves permitted within the UI are found within the ornate "RR" monogram itself, allowing the brand mark to stand out as a refined, human element against the architectural rigidity of the layout.

## Components

- **Buttons:** Primary buttons use a solid Champagne Gold fill with Ink Black text, 0px border-radius, and uppercase Hanken Grotesk labels. Secondary buttons use a transparent background with a 1px Gold border.
- **Cards:** Practice area cards should be minimalist, featuring a large serif number or the monogram watermark, a short headline, and a "Learn More" link with a gold arrow icon.
- **Input Fields:** Dark themed with #262626 backgrounds and 1px borders that transition to Champagne Gold on focus. Labels are always placed above the field in Label-Caps.
- **The "Case Result" Module:** High-contrast blocks using Soft Cream backgrounds with Ink Black serif text, designed to look like high-end editorial pull-quotes.
- **Monogram Placement:** The ornate monogram must appear in the global navigation bar (center-aligned for prestige) and as a large, faint background element in the "About" or "Contact" sections.